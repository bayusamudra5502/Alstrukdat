#include <stdio.h>

int main(){
  printf("Halo");
  return 0;
}
